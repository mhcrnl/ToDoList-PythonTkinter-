# ToDoList-PythonTkinter-
Simple ToDoList in Python     
![Image alt](https://github.com/Sem-Ir-dev/ToDoList-PythonTkinter-/blob/main/screenshot/ToDoScreen.JPG)
